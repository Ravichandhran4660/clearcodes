from django.shortcuts import render
from django.http import HttpResponse
from .models import datalist
# Create your views here.

def home(request):
    return render(request,"home.html")

def open(request):
    return render(request,"open.html")

def form(request):
    return render(request,"form.html")


def data(request):
    if request.method =="POST":
        fname=request.POST.get("fname")
        lname=request.POST.get("lname")
        email=request.POST.get("email")
        file=request.FILES['file']

        datalist.objects.create(fname=fname,lname=lname,email=email,file=file)


        d={'fname':fname,'lname':lname,'email':email,'file':file}
    return render(request,"home.html",d)
    
def show(request):
    a=datalist.objects.all()
    d={"all":a}
    return render(request,"show.html",d)