from django.contrib import admin
from django.urls import path
from apps.views import home,open,form,data,show

urlpatterns = [
    path('home',home),
    path('open',open),
    path('form',form),
    path('data',data),
    path('show',show)
]
