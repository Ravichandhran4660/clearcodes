from django.db import models

# Create your models here.

class datalist(models.Model):
    fname=models.CharField(max_length=55,null=True)
    lname=models.CharField(max_length=55 ,null=True)
    email=models.CharField(max_length=55 ,null=True)
    file=models.FileField(upload_to='uploads/')
    
